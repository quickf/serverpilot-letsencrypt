from rwssl.rwssl import *
if __name__ == '__main__':
	main()
